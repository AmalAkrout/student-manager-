
import javax.swing.JFrame;

public class Execution extends JFrame {
	public static void main (String[] args) {
		new Fenetre();
		}
}
